<!DOCTYPE html>
<html dir="rtl">
<title>W3.CSS</title>
 <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css/w4.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<body>
<div class="w3-container">

  <div class="w3-panel w3-red">
   <h3>Danger!</h3>
     <p>Red often indicates a dangerous or negative situation.</p>
  </div>

  <div class="w3-panel w3-border w3-light-grey w3-round-large">
   <p>London is the most populous city in the United Kingdom,
with a metropolitan area of over 9 million inhabitants.</p>
  </div>

</div>
</body>
</html>
