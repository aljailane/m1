<!DOCTYPE html>
<html dir="rtl">
<title>الجيلاني نت</title>
 <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css/w4.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Scheherazade" rel="stylesheet">
    <style>
.mySlides {display:none}
.w3-left, .w3-right, .w3-badge {cursor:pointer}
.w3-badge {height:13px;width:13px;padding:0}
  </style>

<style type="text/css">
 body,div,p {    font-family: 'Scheherazade', serif; font-size:20px;}
</style>
<style>
.w3-btn {margin-bottom:10px;}
</style>
<body>




<div class="w3-teal">
 <div class="w3-container">
</div>
<h1>التعليم والتجريب</h1>
</div>

<div class="w3-content w3-display-container" style="max-width:800px">
<img class="mySlides" src="images/img_nature_wide.jpg" style="width:100%">
<img class="mySlides" src="images/img_fjords_wide.jpg" style="width:100%">
<img class="mySlides" src="images/img_mountains_wide.jpg" style="width:100%">
<div class="w3-center w3-container w3-section w3-large w3-text-white w3-display-bottommiddle" style="width:100%">
<div class="w3-left w3-hover-text-khaki" onclick="plusDivs(-1)">&#10094;</div>
<div class="w3-right w3-hover-text-khaki" onclick="plusDivs(1)">&#10095;</div>
<span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
<span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
<span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
</div>
</div>
<div class="w3-container">
   <h2>معمل الاكواد</h2>
  <p>نؤمن جيدا ان الثقه بالله و الجد والجهد اساس النجاح</p>
   <div class="w3-panel w3-round-xxlarge w3-teal">
  <p><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</p>
 </div>
<div class="w3-panel w3-round-xxlarge w3-teal">
  <p><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</p>
 </div>
<div class="w3-panel w3-round-xxlarge w3-teal">
  <a href="/"><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</a>
 </div>
<div class="w3-bar">
  <button class="w3-button w3-black">Button</button>
  <button class="w3-button w3-teal">Button</button>
  <button class="w3-button w3-red">Button</button>
</div>
<div class="w3-panel w3-round-xxlarge w3-teal">
  <p><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</p>
 </div>
<div class="w3-panel w3-round-xxlarge w3-teal">
  <p><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</p>
 </div>
<div class="w3-panel w3-round-xxlarge w3-teal">
  <p><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</p>
 </div>
<div class="w3-panel w3-round-xxlarge w3-teal">
  <p><i class="fa fa-arrow-left" style="font-size:20px"></i> 
شرح لوحة التحكم 
</p>
 </div>
  <p><i class="fa fa-spinner w3-spin" style="font-size:64px"></i></p>

  <div class="w3-panel w3-border w3-light-grey w3-round-large">
   <p>London is the most populous city in the United Kingdom,
with a metropolitan area of over 9 million inhabitants.</p>
  </div>
</div>
<img src="images/img_nature_wide.jpg" style="width:30%;cursor:zoom-in"
onclick="document.getElementById('modal01').style.display='block'">

<div id="modal01" class="w3-modal" onclick="this.style.display='none'">
<span class="w3-button w3-hover-red w3-xlarge w3-display-topright">&times;</span>
<div class="w3-modal-content w3-animate-zoom">
  <img src="images/img_nature_wide.jpg" style="width:100%">
</div>
</div>
<script>
function openLeftMenu() {
document.getElementById("leftMenu").style.display = "block";
}
function closeLeftMenu() {
document.getElementById("leftMenu").style.display = "none";
}

function openRightMenu() {
document.getElementById("rightMenu").style.display = "block";
}
function closeRightMenu() {
document.getElementById("rightMenu").style.display = "none";
}
</script>
<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
     dots[i].className = dots[i].className.replace(" w3-white", "");
  }
  x[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " w3-white";
}
</script>
</body>
</html>
