<!DOCTYPE html>
<html dir="rtl">
<head>
<meta charset="UTF-8">
<title>Page Title</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="cache-control" content="no-cache" /> 
<meta http-equiv="Pragma" content="no-cache" />
<link href="https://fonts.googleapis.com/css?family=Amiri" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="//www.fontstatic.com/f=zahra,bahij,bein" />
<style type="text/css">
 body,div,p {    font-family: 'Amiri'; }
</style>
</head>
<body>

<b>الجديد</b>
<br> #- 
<a href="https://aljup.com/add_blocked_ip/" target="_blank" style="color:red;">طلب حظر ايبي من السرفر</a>
<br> #- 
<a href="#" style="color:blue;">اكواد منوعة تفيدك</a>
<br> #- 
<a href="#" style="color:green;">شروحات الموقع وخصائصه</a>
<hr>
<font color="red" size="2">جديد</font><font size="2"> / 
يتم تقديم دليل مقنع ضد اي مزعج لحظره من السرفر
<br>
<font color="red" size="2">جديد</font><font size="2"> / 
تعزيز نظام الحمايه الخاص بالطرد من الشبكة كليا 
<br>
<font color="red" size="2">جديد</font><font size="2"> / 
ازالة معظم اكواد الاعلانات التي تسبب ثقل للشات
</font>
</body>
</html>